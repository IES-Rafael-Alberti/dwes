package daw2a.gestionbiblioteca.controllers;

import daw2a.gestionbiblioteca.dto.prestamo.PrestamoDTO;
import daw2a.gestionbiblioteca.entities.Prestamo;
import daw2a.gestionbiblioteca.services.PrestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/prestamos")
public class PrestamoController {

    private final PrestamoService prestamoService;

    @Autowired
    public PrestamoController(PrestamoService prestamoService) {
        this.prestamoService = prestamoService;
    }

    // Listar todos los préstamos con paginación
    @GetMapping
    public ResponseEntity<Page<PrestamoDTO>> listarPrestamos(Pageable pageable) {
        Page<PrestamoDTO> prestamos = prestamoService.listarPrestamos(pageable);
        return ResponseEntity.ok(prestamos);
    }

    // Obtener los detalles de un préstamo específico
    @GetMapping("/{id}")
    public ResponseEntity<Prestamo> obtenerPrestamo(@PathVariable Long id) {
        Prestamo prestamo = prestamoService.obtenerPrestamoPorId(id);
        return ResponseEntity.ok(prestamo);
    }

    // Crear un nuevo préstamo
    @PostMapping
    public ResponseEntity<Prestamo> crearPrestamo(@RequestBody @Valid Prestamo prestamo) {
        Prestamo nuevoPrestamo = prestamoService.crearPrestamo(prestamo);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPrestamo);
    }

    // Actualizar un préstamo existente
    @PutMapping("/{id}")
    public ResponseEntity<Prestamo> actualizarPrestamo(@PathVariable Long id, @RequestBody @Valid Prestamo prestamoActualizado) {
        Prestamo prestamo = prestamoService.actualizarPrestamo(id, prestamoActualizado);
        return ResponseEntity.ok(prestamo);
    }

    // Endpoint para renovar un préstamo
    @PutMapping("/renovar/{id}")
    public ResponseEntity<Prestamo> renovarPrestamo(@PathVariable Long id, @RequestParam int diasExtension) {
        Prestamo prestamoRenovado = prestamoService.renovarPrestamo(id, diasExtension);
        return ResponseEntity.ok(prestamoRenovado);

    }

    // Registrar la devolución de un préstamo
    @PutMapping("/devolver/{id}")
    public ResponseEntity<Prestamo> devolverPrestamo(@PathVariable Long id) {
        Prestamo prestamo = prestamoService.devolverPrestamo(id);
        return ResponseEntity.ok(prestamo);
    }

    // Eliminar un préstamo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPrestamo(@PathVariable Long id) {
        prestamoService.eliminarPrestamo(id);
        return ResponseEntity.noContent().build();
    }
}