package daw2a.gestionbiblioteca.controllers;

import daw2a.gestionbiblioteca.dto.usuario.CrearUsuarioDTO;
import daw2a.gestionbiblioteca.dto.usuario.ModificarUsuarioDTO;
import daw2a.gestionbiblioteca.dto.usuario.UsuarioDetalleDTO;
import daw2a.gestionbiblioteca.dto.usuario.UsuarioListadoDTO;
import daw2a.gestionbiblioteca.services.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private final UsuarioService usuarioService;

    @Autowired
    public UsuarioController(UsuarioService usuarioService, PasswordEncoder passwordEncoder) {
        this.usuarioService = usuarioService;
    }

        // Listar todos los usuarios con paginación y filtros opcionales
    @GetMapping
    public ResponseEntity<Page<UsuarioListadoDTO>> listarUsuarios(@RequestParam(required = false) String nombre,
                                                                  Pageable pageable) {
      Page<UsuarioListadoDTO> usuarios = usuarioService.listarUsuarios(nombre, pageable);
        return ResponseEntity.ok(usuarios);
    }

    // Obtener los detalles de un usuario específico
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDetalleDTO> obtenerUsuario(@PathVariable Long id) {
        UsuarioDetalleDTO usuario = usuarioService.obtenerUsuario(id);
        return ResponseEntity.ok(usuario);
    }

    //Obtener los detalles de un usuario específico, por email
    @GetMapping("/email")
    public ResponseEntity<UsuarioDetalleDTO> obtenerUsuarioPorEmail(@RequestParam("email") String email) {
        UsuarioDetalleDTO usuario = usuarioService.obtenerUsuarioByEmail(email);
        return ResponseEntity.ok(usuario);
    }

    // Crear un nuevo usuario
    @PostMapping
    public ResponseEntity<UsuarioDetalleDTO> registrarUsuario(@RequestBody @Valid CrearUsuarioDTO crearUsuarioDTO) {
        UsuarioDetalleDTO nuevoUsuario = usuarioService.registrarUsuario(crearUsuarioDTO);
        return ResponseEntity.ok(nuevoUsuario);
    }

//    @GetMapping("/me")
//    public ResponseEntity<ResponseEntity<Usuario>> obtenerMiPerfil(@RequestParam("email") String email) {
//        Usuario usuario = usuarioService.obtenerMiPerfil();
//        return ResponseEntity.ok(ResponseEntity.ok(usuario));
//    }

    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDetalleDTO> actualizarUsuario(@PathVariable Long id,
                                                     @RequestBody ModificarUsuarioDTO modificarUsuarioDTO) {
        UsuarioDetalleDTO usuario = usuarioService.actualizarUsuario(id, modificarUsuarioDTO);
        return ResponseEntity.ok(usuario);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuario(id);
        return ResponseEntity.noContent().build();
    }
}
