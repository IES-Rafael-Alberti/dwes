package daw2a.gestionbiblioteca.services;

import daw2a.gestionbiblioteca.dto.prestamo.PrestamoDTO;
import daw2a.gestionbiblioteca.entities.Libro;
import daw2a.gestionbiblioteca.entities.Prestamo;
import daw2a.gestionbiblioteca.exceptions.LibroNoDisponibleException;
import daw2a.gestionbiblioteca.exceptions.PrestamoVencidoException;
import daw2a.gestionbiblioteca.exceptions.RecursoNoEncontradoException;
import daw2a.gestionbiblioteca.repositories.LibroRepository;
import daw2a.gestionbiblioteca.repositories.PrestamoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class PrestamoService {

    private final PrestamoRepository prestamoRepository;
    private final LibroRepository libroRepository;

    @Autowired
    public PrestamoService(PrestamoRepository prestamoRepository, LibroRepository libroRepository) {
        this.prestamoRepository = prestamoRepository;
        this.libroRepository = libroRepository;
    }

    // Listar todos los préstamos con paginación
    public Page<PrestamoDTO> listarPrestamos(Pageable pageable) {
        return prestamoRepository.findAll(pageable).map(this::convertirAPrestamoDTO);
    }


    // Obtener un préstamo por su ID
    public Prestamo obtenerPrestamoPorId(Long id) {
        return prestamoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Préstamo no encontrado con id " + id));
    }

    // Crear un nuevo préstamo
    @Transactional
    public Prestamo crearPrestamo(Prestamo prestamo) {
        Libro libro = prestamo.getLibro();
        Long usuarioId = prestamo.getUsuario().getId();

        // Verificar si el libro ya está prestado
        if ("prestado".equalsIgnoreCase(libro.getEstado())) {
            throw new LibroNoDisponibleException("El libro ya está prestado.");
        }

        // Verificar si el usuario tiene préstamos vencidos
        if (tienePrestamosVencidos(usuarioId)) {
            throw new PrestamoVencidoException("El usuario tiene préstamos vencidos. No se puede realizar un nuevo préstamo.");
        }

        // Cambiar el estado del libro a "prestado"
        libro.setEstado("prestado");
        libroRepository.save(libro);

        prestamo.setFechaPrestamo(LocalDate.now());
        return prestamoRepository.save(prestamo);
    }

    // Verificar si el usuario tiene préstamos vencidos
    public boolean tienePrestamosVencidos(Long usuarioId) {
        List<Prestamo> prestamos = prestamoRepository.findByUsuarioId(usuarioId);
        return prestamos.stream().anyMatch(Prestamo::estaVencido);
    }

    // Actualizar un préstamo existente
    public Prestamo actualizarPrestamo(Long id, Prestamo prestamoActualizado) {
        return prestamoRepository.findById(id)
                .map(prestamo -> {
                    prestamo.setFechaPrestamo(prestamoActualizado.getFechaPrestamo());
                    prestamo.setFechaDevolucion(prestamoActualizado.getFechaDevolucion());
                    return prestamoRepository.save(prestamo);
                })
                .orElseThrow(() -> new RecursoNoEncontradoException("Préstamo no encontrado con id " + id));
    }

    // Renovar un préstamo existente
    @Transactional
    public Prestamo renovarPrestamo(Long prestamoId, int diasExtension) {
        return prestamoRepository.findById(prestamoId)
                .map(prestamo -> {
                    // Verificar si el préstamo es renovable (por ejemplo, si aún no está vencido)
                    if (prestamo.estaVencido()) {
                        throw new PrestamoVencidoException("No se puede renovar un préstamo vencido."); //PrestamoNoRenovableException
                    }

                    // Extender la fecha de devolución
                    prestamo.setFechaPrestamo(prestamo.getFechaPrestamo().plusDays(diasExtension));
                    return prestamoRepository.save(prestamo);
                })
                .orElseThrow(() -> new RecursoNoEncontradoException("Préstamo no encontrado con id " + prestamoId));
    }


    // Registrar la devolución de un préstamo
    @Transactional
    public Prestamo devolverPrestamo(Long id) {
        return prestamoRepository.findById(id)
                .map(prestamo -> {
                    Libro libro = prestamo.getLibro();

                    // Cambiar el estado del libro a "disponible"
                    libro.setEstado("disponible");
                    libroRepository.save(libro); // Guardar el cambio de estado

                    // Actualizar la fecha de devolución del préstamo
                    prestamo.setFechaDevolucion(LocalDate.now());
                    return prestamoRepository.save(prestamo);
                })
                .orElseThrow(() -> new RecursoNoEncontradoException("Préstamo no encontrado con id " + id));
    }

    // Eliminar un préstamo, en una aplicación real no se eliminarían los préstamos, se perdería la trazabilidad
    // de los préstamos realizados
    // La única situación en que se eliminaría un préstamo sería si se trata de un error en la creación del préstamo
    public void eliminarPrestamo(Long id) {
        Prestamo prestamo = prestamoRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Préstamo no encontrado con id " + id));
        prestamo.getLibro().setEstado("disponible");
        prestamoRepository.delete(prestamo);
    }


    private PrestamoDTO convertirAPrestamoDTO(Prestamo prestamo) {
       PrestamoDTO dto = new PrestamoDTO();
       dto.setId(prestamo.getId());
       dto.setLibroId(prestamo.getLibro().getId());
       dto.setLibroTitulo(prestamo.getLibro().getTitulo());
       dto.setUsuarioId(prestamo.getUsuario().getId());
       dto.setFechaPrestamo(prestamo.getFechaPrestamo());
       dto.setFechaDevolucion(prestamo.getFechaDevolucion());

       return dto;
    }

}
