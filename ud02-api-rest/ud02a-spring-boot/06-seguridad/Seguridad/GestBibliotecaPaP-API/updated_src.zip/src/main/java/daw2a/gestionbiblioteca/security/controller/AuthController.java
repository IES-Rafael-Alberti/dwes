package daw2a.gestionbiblioteca.security.controller;

import daw2a.gestionbiblioteca.security.dto.AuthRequest;
import daw2a.gestionbiblioteca.security.dto.AuthResponse;
import daw2a.gestionbiblioteca.security.jwt.JwtUtil;
import daw2a.gestionbiblioteca.security.user.CustomUserDetails;
import daw2a.gestionbiblioteca.security.user.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;

    private final JwtUtil jwtUtil;

    public AuthController(AuthenticationManager authenticationManager, JwtUtil jwtUtil) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/authenticate")
    public AuthResponse authenticate(@RequestBody AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        String token = jwtUtil.generateToken((CustomUserDetails) authentication.getPrincipal());
        return new AuthResponse(token);
    }
    @PostMapping("/register")
    public AuthResponse register(@RequestBody AuthRequest request) {
        // NOT IMPLEMENTED
        return null;

    }
}