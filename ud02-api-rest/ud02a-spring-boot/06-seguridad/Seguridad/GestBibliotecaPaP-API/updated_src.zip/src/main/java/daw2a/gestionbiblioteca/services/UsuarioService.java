package daw2a.gestionbiblioteca.services;

import daw2a.gestionbiblioteca.dto.usuario.CrearUsuarioDTO;
import daw2a.gestionbiblioteca.dto.usuario.ModificarUsuarioDTO;
import daw2a.gestionbiblioteca.dto.usuario.UsuarioDetalleDTO;
import daw2a.gestionbiblioteca.dto.usuario.UsuarioListadoDTO;
import daw2a.gestionbiblioteca.entities.Usuario;
import daw2a.gestionbiblioteca.enums.Rol;
import daw2a.gestionbiblioteca.exceptions.RecursoDuplicadoException;
import daw2a.gestionbiblioteca.exceptions.RecursoNoEncontradoException;
import daw2a.gestionbiblioteca.repositories.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
//import org.springframework.security.core.context.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;

@Service
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Implementar métodos de servicio
    // Listar todos los usuarios
    public Page<UsuarioListadoDTO> listarUsuarios(String nombre, Pageable pageable) {
        Page<Usuario> usuarios = (nombre != null)
                ? usuarioRepository.findByNombreContainingIgnoreCase(nombre, pageable)
                : usuarioRepository.findAll(pageable);

        return usuarios.map(this::convertirAUsuarioListadoDTO);
    }

    // Obtener los detalles de un usuario específico, por id
    public UsuarioDetalleDTO obtenerUsuario(Long id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id " + id));
        return convertirAUsuarioDetalleDTO(usuario);
    }

    // Obtener los detalles de un usuario específico, por email
    public UsuarioDetalleDTO obtenerUsuarioByEmail(String email) {
        Usuario usuario=usuarioRepository.findUsuarioByEmail(email)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con email " + email));
        return convertirAUsuarioDetalleDTO(usuario);
    }

    // Obtener los detalles de un usuario actualmente autenticado
    /*
    public Usuario obtenerMiPerfil() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        // Verificar si el usuario está autenticado
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RecursoNoEncontradoException("Usuario no autenticado.");
        }

        // Obtener el email del usuario autenticado
        String email = authentication.getName();

        // Buscar el usuario por email
        return usuarioRepository.findUsuarioByEmail(email)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con email " + email));
    }*/



    // Registrar(crear) un nuevo usuario
    public UsuarioDetalleDTO registrarUsuario(@Valid CrearUsuarioDTO crearUsuarioDTO) {
        // Verificar si el email ya está en uso
        if (usuarioRepository.findUsuarioByEmail(crearUsuarioDTO.getEmail()).isPresent()) {
            throw new RecursoDuplicadoException("El email " + crearUsuarioDTO.getEmail() + " ya está en uso.");
        }
        // Crear una n
        // ueva entidad Usuario
        Usuario usuario = new Usuario();
        usuario.setNombre(crearUsuarioDTO.getNombre());
        usuario.setEmail(crearUsuarioDTO.getEmail());
        usuario.setPassword(passwordEncoder.encode(crearUsuarioDTO.getPassword()));
        usuario.setRol(Rol.valueOf(crearUsuarioDTO.getRol().toUpperCase()));

        // Guardar el usuario en la base de datos
        Usuario usuarioGuardado = usuarioRepository.save(usuario);

        // Convertir la entidad guardada a UsuarioDetalleDTO
        return convertirAUsuarioDetalleDTO(usuarioGuardado);
    }

    // Actualizar un usuario existente
    public UsuarioDetalleDTO actualizarUsuario(Long id, ModificarUsuarioDTO modificarUsuarioDTO) {
        // Buscar el usuario existente
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id " + id));

        // Actualizar campos solo si no son nulos
        if (modificarUsuarioDTO.getNombre() != null) {
            usuario.setNombre(modificarUsuarioDTO.getNombre());
        }
        if (modificarUsuarioDTO.getEmail() != null) {
            usuario.setEmail(modificarUsuarioDTO.getEmail());
        }
        if (modificarUsuarioDTO.getPassword() != null) {
            usuario.setPassword(passwordEncoder.encode(modificarUsuarioDTO.getPassword()));
        }
        if (modificarUsuarioDTO.getRol() != null) {
            usuario.setRol(Rol.valueOf(modificarUsuarioDTO.getRol().toUpperCase()));
        }

        // Guardar cambios y devolver los detalles actualizados como DTO
        Usuario usuarioActualizado = usuarioRepository.save(usuario);
        return convertirAUsuarioDetalleDTO(usuarioActualizado);
    }

    // Método para eliminar un usuario existente
    public void eliminarUsuario(Long id) {
        // Buscar el usuario por ID o lanzar una excepción si no existe
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id " + id));
        // Eliminar el usuario de la base de datos
        usuarioRepository.delete(usuario);

        /*alternativa
        public void eliminarUsuario(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new RecursoNoEncontradoException("Usuario no encontrado con id " + id);
        }
        usuarioRepository.deleteById(id);
    }
         */
    }

    // Métodos de conversión
    private UsuarioDetalleDTO convertirAUsuarioDetalleDTO(Usuario usuario) {
        UsuarioDetalleDTO dto = new UsuarioDetalleDTO();
        dto.setId(usuario.getId());
        dto.setNombre(usuario.getNombre());
        dto.setEmail(usuario.getEmail());
        dto.setRol(usuario.getRol().name());
        return dto;
    }

    private UsuarioListadoDTO convertirAUsuarioListadoDTO(Usuario usuario) {
        UsuarioListadoDTO dto = new UsuarioListadoDTO();
        dto.setId(usuario.getId());
        dto.setNombre(usuario.getNombre());
        dto.setEmail(usuario.getEmail());
        return dto;
    }

}
