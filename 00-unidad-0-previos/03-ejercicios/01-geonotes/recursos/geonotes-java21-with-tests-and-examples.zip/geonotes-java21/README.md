# GeoNotes (Java 21)

Mini‑proyecto para clase (Java para programadores de Kotlin). Incluye:
- records, sealed interfaces, switch expressions
- pattern matching (incl. record patterns, Java 21)
- text blocks
- sequenced collections
- demo breve de virtual threads

## Requisitos
- JDK 21 (o superior)
- Gradle 8+ (o abrir con IntelliJ y que importe Gradle)

## Abrir en IntelliJ
1. File → Open... → carpeta del proyecto.
2. Importar como Proyecto Gradle.
3. Ejecutar: Tasks > application > run (o `gradle run`).
## Tests
- Ejecutar tests: `gradle test`

## Gradle Wrapper
- Para generar el wrapper localmente (si no aparece en el proyecto), ejecuta:
  ```bash
  gradle wrapper --gradle-version 8.9
  ./gradlew run
  ```

## DemoExamples
- Ejecutar con: `gradle run --args='demo'` o simplemente `java DemoExamples`
  Muestra varias notas de ejemplo en formato JSON.

## Script de ejemplos
- Ejecutar solo los ejemplos (sin entrar al menú CLI):
  ```bash
  gradle run --args='examples'
  ```
