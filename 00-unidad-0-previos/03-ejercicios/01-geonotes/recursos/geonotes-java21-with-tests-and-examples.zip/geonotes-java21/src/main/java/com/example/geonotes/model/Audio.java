package com.example.geonotes.model;

public record Audio(String url, int seconds) implements Attachment {}