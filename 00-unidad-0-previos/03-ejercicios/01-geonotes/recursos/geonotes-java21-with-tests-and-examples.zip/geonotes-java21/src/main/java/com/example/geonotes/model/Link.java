package com.example.geonotes.model;

public record Link(String url, String label) implements Attachment {}