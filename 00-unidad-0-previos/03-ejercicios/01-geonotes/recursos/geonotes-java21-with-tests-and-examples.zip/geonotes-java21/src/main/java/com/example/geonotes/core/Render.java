package com.example.geonotes.core;

import com.example.geonotes.model.Note;

public final class Render {
  private Render() {}

  public static String toJson(Note n) {
    String json = """
      {
        "id": %d,
        "title": "%s",
        "content": "%s",
        "location": { "lat": %.6f, "lon": %.6f },
        "createdAt": "%s"
      }
      """.formatted(
        n.id(), n.title(), escape(n.content()),
        n.location().lat(), n.location().lon(), n.createdAt()
      );
    return json;
  }

  private static String escape(String s) { return s.replace(""", "\""); }
}