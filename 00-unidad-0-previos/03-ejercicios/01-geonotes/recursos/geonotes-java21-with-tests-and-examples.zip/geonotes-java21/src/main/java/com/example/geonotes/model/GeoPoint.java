package com.example.geonotes.model;

public record GeoPoint(double lat, double lon) {
  public GeoPoint {
    if (Double.isNaN(lat) || lat < -90 || lat > 90) {
      throw new IllegalArgumentException("lat fuera de rango [-90,90]");
    }
    if (Double.isNaN(lon) || lon < -180 || lon > 180) {
      throw new IllegalArgumentException("lon fuera de rango [-180,180]");
    }
  }
}