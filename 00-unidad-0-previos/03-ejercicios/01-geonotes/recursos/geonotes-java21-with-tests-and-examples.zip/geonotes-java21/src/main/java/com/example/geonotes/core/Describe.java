package com.example.geonotes.core;

import com.example.geonotes.model.*;

public final class Describe {
  private Describe() {}

  public static String attachmentLabel(Attachment a) {
    return switch (a) {
      case Photo p when p.width() >= 1920 -> "📷 Photo (HD)";
      case Photo p                        -> "📷 Photo";
      case Audio a1 when a1.seconds() > 300 -> "🎵 Audio (largo)";
      case Audio a1                          -> "🎵 Audio";
      case Link l                            -> "🔗 " + (l.label() == null ? l.url() : l.label());
    };
  }

  public static int mediaSize(Object o) {
    if (o instanceof Photo p) {
      return p.width() * p.height();
    } else if (o instanceof Audio a) {
      return a.seconds();
    } else {
      return 0;
    }
  }
}