package com.example.geonotes.tools;

import com.example.geonotes.core.Render;
import com.example.geonotes.core.Timeline;
import com.example.geonotes.model.GeoPoint;
import com.example.geonotes.model.Note;

import java.time.Instant;

public final class Examples {
  private Examples() {}

  public static void run() {
    Timeline t = new Timeline();
    t.addLast(new Note(1001, "Cádiz", "Caleta", new GeoPoint(36.5297, -6.2927), Instant.now()));
    t.addLast(new Note(1002, "Sevilla", "Alfalfa", new GeoPoint(37.3891, -5.9845), Instant.now()));
    t.addFirst(new Note(1000, "Córdoba", "Mezquita", new GeoPoint(37.879, -4.7794), Instant.now()));
    System.out.println("=== EJEMPLOS (orden normal) ===");
    t.values().forEach(n -> System.out.println(Render.toJson(n)));
    System.out.println("=== EJEMPLOS (reversed view) ===");
    t.reversedView().values().forEach(n -> System.out.println(Render.toJson(n)));
  }
}