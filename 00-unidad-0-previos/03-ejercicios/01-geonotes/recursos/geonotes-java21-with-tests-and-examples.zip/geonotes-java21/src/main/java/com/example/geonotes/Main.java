package com.example.geonotes;

import com.example.geonotes.core.*;
import com.example.geonotes.model.*;
import java.time.Instant;
import java.util.Scanner;

public class Main {
  private static final Timeline timeline = new Timeline();
  private static final Scanner sc = new Scanner(System.in);

  public static void main(String[] args) {

// Modo ejemplos: ejecutar script y salir
if (args != null && args.length > 0 && "examples".equalsIgnoreCase(args[0])) {
  com.example.geonotes.tools.Examples.run();
  return;
}
    seed();
    loop();
  }

  private static void loop() {
    while (true) {
      String menu = """
        === GeoNotes ===
        1) Añadir nota al final
        2) Añadir nota al inicio
        3) Listar
        4) Listar (reversed)
        5) Region de punto
        vt) Demo Virtual Threads (opcional)
        0) Salir
        Opción: 
        """;
      System.out.print(menu);
      String opt = sc.nextLine().trim();
      switch (opt) {
        case "1" -> addNote(false);
        case "2" -> addNote(true);
        case "3" -> list(false);
        case "4" -> list(true);
        case "5" -> regionQuery();
        case "vt" -> runVT();
        case "0" -> { System.out.println("Adiós!"); return; }
        default -> System.out.println("Opción inválida");
      }
    }
  }

  private static void runVT() {
    try {
      AsyncDemo.runManyIO();
    } catch (Exception e) {
      System.out.println("Error VT: " + e.getMessage());
    }
  }

  private static void addNote(boolean first) {
    try {
      System.out.print("Título: ");
      String t = sc.nextLine();
      System.out.print("Contenido: ");
      String c = sc.nextLine();
      System.out.print("lat: "); double lat = Double.parseDouble(sc.nextLine());
      System.out.print("lon: "); double lon = Double.parseDouble(sc.nextLine());
      long id = System.currentTimeMillis();
      Note n = new Note(id, t, c, new GeoPoint(lat, lon), java.time.Instant.now());
      if (first) timeline.addFirst(n); else timeline.addLast(n);
      System.out.println("OK\n" + Render.toJson(n));
    } catch (Exception e) {
      System.out.println("Error: " + e.getMessage());
    }
  }

  private static void list(boolean reversed) {
    var view = reversed ? timeline.reversedView().values() : timeline.values();
    for (Note n : view) {
      System.out.println(Render.toJson(n));
    }
  }

  private static void regionQuery() {
    try {
      System.out.print("lat: "); double lat = Double.parseDouble(sc.nextLine());
      System.out.print("lon: "); double lon = Double.parseDouble(sc.nextLine());
      System.out.println(Match.region(new GeoPoint(lat, lon)));
    } catch (Exception e) {
      System.out.println("Error: " + e.getMessage());
    }
  }

  private static void seed() {
    timeline.addLast(new Note(1, "Cádiz", "Playita", new GeoPoint(36.5297, -6.2927), Instant.now()));
    timeline.addLast(new Note(2, "Sevilla", "Triana", new GeoPoint(37.3826, -5.9963), Instant.now()));
  }
}