package com.example.geonotes.model;

public sealed interface Attachment permits Photo, Audio, Link {}