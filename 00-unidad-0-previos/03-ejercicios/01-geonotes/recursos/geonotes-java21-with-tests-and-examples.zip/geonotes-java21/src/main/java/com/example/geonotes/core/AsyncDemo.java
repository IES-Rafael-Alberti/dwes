package com.example.geonotes.core;

import java.util.concurrent.*;

public final class AsyncDemo {
  private AsyncDemo() {}

  public static void runManyIO() throws Exception {
    try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
      Future<?> f1 = exec.submit(() -> slowIO(1));
      Future<?> f2 = exec.submit(() -> slowIO(2));
      f1.get(); f2.get();
    }
  }

  private static void slowIO(int id) {
    try {
      Thread.sleep(500);
      System.out.println("IO " + id + " OK en " + Thread.currentThread());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
    }
  }
}