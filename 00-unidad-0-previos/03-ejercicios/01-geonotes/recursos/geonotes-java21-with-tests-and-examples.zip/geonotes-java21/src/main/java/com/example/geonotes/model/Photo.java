package com.example.geonotes.model;

public record Photo(String url, int width, int height) implements Attachment {}