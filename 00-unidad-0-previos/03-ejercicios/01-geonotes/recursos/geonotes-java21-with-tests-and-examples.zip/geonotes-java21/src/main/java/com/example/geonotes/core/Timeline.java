package com.example.geonotes.core;

import com.example.geonotes.model.Note;
import java.util.*;

public final class Timeline {
  private final SequencedMap<Long, Note> notes = new LinkedHashMap<>();

  public void addFirst(Note n) { notes.putFirst(n.id(), n); }
  public void addLast(Note n)  { notes.putLast(n.id(), n); }

  public Note first()  { return notes.firstEntry().getValue(); }
  public Note last()   { return notes.lastEntry().getValue(); }

  public SequencedMap<Long, Note> reversedView() { return notes.reversed(); }
  public Collection<Note> values() { return notes.values(); }
}