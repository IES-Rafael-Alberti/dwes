package com.example.geonotes.core;

import com.example.geonotes.model.*;

public final class Match {
  private Match() {}

  public static String region(GeoPoint p) {
    return switch (p) {
      case GeoPoint(double lat, double lon) when lat == 0 && lon == 0 -> "ORIGIN";
      case GeoPoint(double lat, double lon) when lat == 0 -> "Equator";
      case GeoPoint(double lat, double lon) when lon == 0 -> "Greenwich";
      case GeoPoint(double lat, double lon) -> "(" + lat + "," + lon + ")";
    };
  }

  public static boolean contains(GeoArea r, GeoPoint p) {
    if (r instanceof GeoArea(GeoPoint(double x1, double y1), GeoPoint(double x2, double y2))) {
      double lat = p.lat();
      double lon = p.lon();
      return lat >= Math.min(x1, x2) && lat <= Math.max(x1, x2)
          && lon >= Math.min(y1, y2) && lon <= Math.max(y1, y2);
    }
    return false;
  }
}