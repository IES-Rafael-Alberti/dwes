package com.example.geonotes.model;

public record GeoArea(GeoPoint topLeft, GeoPoint bottomRight) {}