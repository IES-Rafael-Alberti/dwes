package com.example.geonotes;

import com.example.geonotes.core.Render;
import com.example.geonotes.model.*;
import java.time.Instant;

public class DemoExamples {
  public static void main(String[] args) {
    Note n1 = new Note(100, "Granada", "Alhambra", new GeoPoint(37.1761, -3.5881), Instant.now());
    Note n2 = new Note(101, "Málaga", "Costa del Sol", new GeoPoint(36.7213, -4.4214), Instant.now());
    Note n3 = new Note(102, "Madrid", "Capital", new GeoPoint(40.4168, -3.7038), Instant.now());

    System.out.println(Render.toJson(n1));
    System.out.println(Render.toJson(n2));
    System.out.println(Render.toJson(n3));
  }
}