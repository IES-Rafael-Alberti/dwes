package com.example.geonotes.core;

import com.example.geonotes.model.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DescribeTest {

  @Test
  void attachmentLabel_photoHd_and_audioLong_and_linkLabel() {
    Attachment hd = new Photo("http://img", 1920, 1080);
    Attachment photo = new Photo("http://img", 1000, 800);
    Attachment longAudio = new Audio("http://aud", 600);
    Attachment linkWithLabel = new Link("http://k", "Kotlin");
    Attachment linkNoLabel = new Link("http://java", null);

    assertTrue(Describe.attachmentLabel(hd).contains("HD"));
    assertEquals("📷 Photo", Describe.attachmentLabel(photo));
    assertTrue(Describe.attachmentLabel(longAudio).contains("largo"));
    assertTrue(Describe.attachmentLabel(linkWithLabel).contains("Kotlin"));
    assertTrue(Describe.attachmentLabel(linkNoLabel).contains("http://java"));
  }

  @Test
  void mediaSize_photoVsAudio() {
    Photo p = new Photo("u", 10, 20);
    Audio a = new Audio("u", 7);
    assertEquals(200, Describe.mediaSize(p));
    assertEquals(7, Describe.mediaSize(a));
    assertEquals(0, Describe.mediaSize("otro"));
  }
}