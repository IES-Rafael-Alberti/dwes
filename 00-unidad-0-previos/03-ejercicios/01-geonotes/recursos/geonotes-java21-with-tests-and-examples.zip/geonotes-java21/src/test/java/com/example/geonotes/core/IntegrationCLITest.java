package com.example.geonotes.core;

import com.example.geonotes.Main;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class IntegrationCLITest {

  @Test
  @Timeout(value = 10, unit = TimeUnit.SECONDS)
  void runMain_addListExit_flow() {
    // Simula: 1 (add last) -> Título -> Contenido -> lat -> lon -> 3 (listar) -> 0 (salir)
    String input = String.join("\n",
      "1",
      "Nota test",
      "Contenido test",
      "36.5",
      "-6.2",
      "3",
      "0",
      ""  // última línea para enter final
    );
    ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
    ByteArrayOutputStream outBuf = new ByteArrayOutputStream();
    PrintStream out = new PrintStream(outBuf, true, StandardCharsets.UTF_8);

    PrintStream prevOut = System.out;
    java.io.InputStream prevIn = System.in;
    try {
      System.setIn(in);
      System.setOut(out);
      Main.main(new String[0]);
    } finally {
      System.setIn(prevIn);
      System.setOut(prevOut);
    }

    String output = outBuf.toString(StandardCharsets.UTF_8);
    // Debe contener el JSON con el título que agregamos y la clave "location"
    assertTrue(output.contains("Nota test"));
    assertTrue(output.contains(""location""));
  }
}