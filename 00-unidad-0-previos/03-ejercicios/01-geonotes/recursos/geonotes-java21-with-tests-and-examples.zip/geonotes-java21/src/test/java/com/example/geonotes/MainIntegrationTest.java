package com.example.geonotes;

import org.junit.jupiter.api.Test;
import java.io.*;
import static org.junit.jupiter.api.Assertions.*;

public class MainIntegrationTest {

  @Test
  void testListNotesAfterSeed() throws Exception {
    // Simular entrada: opción 3 (listar), luego 0 (salir)
    String input = "3\n0\n";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    PrintStream oldOut = System.out;
    InputStream oldIn = System.in;
    try {
      System.setIn(in);
      System.setOut(new PrintStream(out));
      Main.main(new String[]{});
    } finally {
      System.setIn(oldIn);
      System.setOut(oldOut);
    }
    String output = out.toString();
    assertTrue(output.contains("Cádiz") && output.contains("Sevilla"));
  }
}