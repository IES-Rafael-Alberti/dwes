package com.example.geonotes.core;

import com.example.geonotes.model.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MatchTest {

  @Test
  void contains_pointInsideArea_returnsTrue() {
    GeoArea area = new GeoArea(new GeoPoint(10, 10), new GeoPoint(20, 20));
    GeoPoint p = new GeoPoint(15, 15);
    assertTrue(Match.contains(area, p));
  }

  @Test
  void contains_pointOutsideArea_returnsFalse() {
    GeoArea area = new GeoArea(new GeoPoint(10, 10), new GeoPoint(20, 20));
    GeoPoint p = new GeoPoint(9, 21);
    assertFalse(Match.contains(area, p));
  }

  @Test
  void region_origin_equator_greenwich_and_other() {
    assertEquals("ORIGIN", Match.region(new GeoPoint(0, 0)));
    assertEquals("Equator", Match.region(new GeoPoint(0, 5)));
    assertEquals("Greenwich", Match.region(new GeoPoint(5, 0)));
    String other = Match.region(new GeoPoint(1, 2));
    assertTrue(other.contains("(") && other.contains(","));
  }
}