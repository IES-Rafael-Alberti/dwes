package com.example.calc.api.error;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import org.springframework.web.context.request.WebRequest;
import java.time.Instant;
@RestControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler(IllegalArgumentException.class)
  public ResponseEntity<ApiError> handleBadRequest(IllegalArgumentException ex, WebRequest req) {
    var err = new ApiError(ex.getMessage(), req.getDescription(false), HttpStatus.BAD_REQUEST.value(), Instant.now());
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
  }
  @ExceptionHandler(Exception.class)
  public ResponseEntity<ApiError> handleGeneric(Exception ex, WebRequest req) {
    var err = new ApiError("Error interno", req.getDescription(false), HttpStatus.INTERNAL_SERVER_ERROR.value(), Instant.now());
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(err);
  }
}