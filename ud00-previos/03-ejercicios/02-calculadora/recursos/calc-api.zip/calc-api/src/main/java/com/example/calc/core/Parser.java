package com.example.calc.core;
import java.util.List;

public final class Parser {
  private final List<Token> ts;
  private int i = 0;

  public Parser(List<Token> ts) { this.ts = ts; }

  public Expr parse() {
    Expr e = expr();
    expect(TokenType.EOF);
    return e;
  }

  // Grammar:
  // expr   -> term (('+'|'-') term)*
  // term   -> factor (('*'|'/') factor)*
  // factor -> power
  // power  -> unary ('^' power)?    // right-assoc
  // unary  -> ('+'|'-') unary | primary
  // primary-> NUMBER | IDENT '(' expr ')' | '(' expr ')'

  private Expr expr() {
    Expr e = term();
    while (match(TokenType.PLUS) || match(TokenType.MINUS)) {
      char op = prev().lexeme().charAt(0);
      Expr r = term();
      e = new Binary(e, op, r);
    }
    return e;
  }

  private Expr term() {
    Expr e = factor();
    while (match(TokenType.STAR) || match(TokenType.SLASH)) {
      char op = prev().lexeme().charAt(0);
      Expr r = factor();
      e = new Binary(e, op, r);
    }
    return e;
  }

  private Expr factor() { return power(); }

  private Expr power() {
    Expr left = unary();
    if (match(TokenType.CARET)) {
      Expr right = power(); // right associative
      return new Binary(left, '^', right);
    }
    return left;
  }

  private Expr unary() {
    if (match(TokenType.PLUS) || match(TokenType.MINUS)) {
      char op = prev().lexeme().charAt(0);
      return new Unary(op, unary());
    }
    return primary();
  }

  private Expr primary() {
    if (match(TokenType.NUMBER)) {
      return new NumberLit(Double.parseDouble(prev().lexeme()));
    }
    if (match(TokenType.IDENT)) {
      String name = prev().lexeme();
      expect(TokenType.LPAREN);
      Expr a = expr();
      expect(TokenType.RPAREN);
      return new Call(name, a);
    }
    if (match(TokenType.LPAREN)) {
      Expr e = expr();
      expect(TokenType.RPAREN);
      return e;
    }
    throw error("Token inesperado: " + peek().type() + " en pos " + peek().pos());
  }

  private boolean match(TokenType t) {
    if (check(t)) { i++; return true; }
    return false;
  }

  private void expect(TokenType t) {
    if (!check(t)) throw error("Esperaba " + t + " pero vi " + peek().type());
    i++;
  }

  private boolean check(TokenType t) { return !eof() && peek().type() == t; }
  private boolean eof() { return peek().type() == TokenType.EOF; }
  private Token peek() { return ts.get(i); }
  private Token prev() { return ts.get(i - 1); }

  private IllegalArgumentException error(String msg) { return new IllegalArgumentException(msg); }
}