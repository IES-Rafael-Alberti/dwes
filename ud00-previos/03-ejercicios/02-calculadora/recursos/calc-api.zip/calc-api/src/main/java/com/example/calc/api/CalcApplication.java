package com.example.calc.api;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication(scanBasePackages = "com.example.calc")
public class CalcApplication {
  public static void main(String[] args) { SpringApplication.run(CalcApplication.class, args); }
}