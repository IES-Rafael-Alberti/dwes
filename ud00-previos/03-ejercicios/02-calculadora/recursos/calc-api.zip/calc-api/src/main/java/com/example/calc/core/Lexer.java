package com.example.calc.core;
import java.util.ArrayList;
import java.util.List;

public final class Lexer {
  private final String s;
  private int i = 0;

  public Lexer(String s) { this.s = s; }

  public List<Token> lex() {
    List<Token> out = new ArrayList<>();
    while (!eof()) {
      char c = s.charAt(i);
      if (Character.isWhitespace(c)) { i++; continue; }
      switch (c) {
        case '+': out.add(tok(TokenType.PLUS, "+")); i++; break;
        case '-': out.add(tok(TokenType.MINUS, "-")); i++; break;
        case '*': out.add(tok(TokenType.STAR, "*")); i++; break;
        case '/': out.add(tok(TokenType.SLASH, "/")); i++; break;
        case '^': out.add(tok(TokenType.CARET, "^")); i++; break;
        case '(': out.add(tok(TokenType.LPAREN, "(")); i++; break;
        case ')': out.add(tok(TokenType.RPAREN, ")")); i++; break;
        default: {
          if (Character.isDigit(c) || c == '.') {
            out.add(number());
          } else if (Character.isAlphabetic(c)) {
            out.add(ident());
          } else {
            throw new IllegalArgumentException("Caracter inesperado: '" + c + "' en pos " + i);
          }
        }
      }
    }
    out.add(new Token(TokenType.EOF, "", i));
    return out;
  }

  private boolean eof() { return i >= s.length(); }

  private Token tok(TokenType t, String lx) { return new Token(t, lx, i); }

  private Token number() {
    int start = i;
    boolean dot = false;
    while (!eof()) {
      char c = s.charAt(i);
      if (Character.isDigit(c)) { i++; }
      else if (c == '.' && !dot) { dot = true; i++; }
      else break;
    }
    return new Token(TokenType.NUMBER, s.substring(start, i), start);
  }

  private Token ident() {
    int start = i;
    while (!eof()) {
      char c = s.charAt(i);
      if (Character.isAlphabetic(c) || Character.isDigit(c) || c == '_') i++;
      else break;
    }
    return new Token(TokenType.IDENT, s.substring(start, i), start);
  }
}