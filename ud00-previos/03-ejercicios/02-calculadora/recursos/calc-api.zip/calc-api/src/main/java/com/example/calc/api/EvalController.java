package com.example.calc.api;
import com.example.calc.api.dto.*; import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1")
public class EvalController {
  private final CalcService service;
  public EvalController(CalcService service) { this.service = service; }
  @PostMapping("/eval")
  public ResponseEntity<EvalResponse> eval(@RequestBody EvalRequest req) {
    double result = service.evaluate(req.expr());
    return ResponseEntity.ok(new EvalResponse(req.expr(), result));
  }
  @GetMapping("/health")
  public String health() { return "OK"; }
}