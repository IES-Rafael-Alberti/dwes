package com.example.calc.api;
import com.example.calc.core.*; import org.springframework.stereotype.Service;
@Service
public class CalcService {
  public double evaluate(String expr) {
    if (expr == null || expr.isBlank()) throw new IllegalArgumentException("La expresión no puede estar vacía");
    var tokens = new Lexer(expr).lex();
    var ast = new Parser(tokens).parse();
    return Evaluator.eval(ast);
  }
}