package com.example.calc.api;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class EvalControllerIT {
  @Autowired MockMvc mvc;

  @Test
  void eval_ok() throws Exception {
    mvc.perform(post("/api/v1/eval")
      .contentType(MediaType.APPLICATION_JSON)
      .content("{"expr":"2+3*4"}"))
      .andExpect(status().isOk())
      .andExpect(jsonPath("$.result").value(14.0));
  }
}