# calc-api (Spring Boot 3 + Java 21)

API REST que expone la calculadora educativa:
- POST `/api/v1/eval` → `{ "expr": "2 + 3 * 4" }` → `{ "expr": "...", "result": 14.0 }`
- GET `/health` → "OK"
- Swagger UI: `/swagger-ui.html`

## Arrancar

### Opción 1: con Gradle instalado una vez
```bash
gradle wrapper --gradle-version 8.9   # (solo si falta el jar del wrapper)
./gradlew bootRun
```

### Opción 2: desde IntelliJ
- Abrir el proyecto y ejecutar la configuración "CalcApplication".

## Tests
```bash
./gradlew test
```